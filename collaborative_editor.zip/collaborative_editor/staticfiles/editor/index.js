import React from 'react';
import ReactDOM from 'react-dom';
import EditorComponent from './editor_component';
import VersionHistory from './VersionHistory';  // Import VersionHistory component

document.addEventListener('DOMContentLoaded', () => {
    // Render the EditorComponent if the root element for the editor is present
    const editorRootElement = document.getElementById('editor-root');
    if (editorRootElement) {
        const initialContent = editorRootElement.dataset.content;

        ReactDOM.render(
            <EditorComponent
                documentContent={initialContent}
                onContentChange={(newContent) => {
                    // Send updated content to the WebSocket server here (if needed)
                    console.log("Document updated content: ", newContent);
                }}
            />,
            editorRootElement
        );
    }

    // Render the VersionHistory component if the version-history-root is present
    const versionHistoryRootElement = document.getElementById('version-history-root');
    if (versionHistoryRootElement) {
        ReactDOM.render(
            <VersionHistory />,
            versionHistoryRootElement
        );
    }
});
