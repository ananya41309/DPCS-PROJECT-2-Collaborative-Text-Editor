"""
URL configuration for collaborative_editor project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path("", views.home, name="home")
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path("", Home.as_view(), name="home")
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path("blog/", include("blog.urls"))
"""
from django.contrib import admin
from django.urls import path, include, re_path
from editor import views
from django.conf import settings
from django.conf.urls.static import static
from editor import consumers  # Make sure 'consumers' is correctly imported from the 'editor' app

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("admin/", admin.site.urls),
    path('dashboard/', views.dashboard, name='dashboard'),
    path("accounts/", include("allauth.urls")),
    path("accounts/profile/", views.profile_view, name="profile"),
    path("document/create/", views.create_document, name="create_document"),
    path("document/edit/<int:doc_id>/", views.edit_document, name="edit_document"),
    path('document/share/<int:doc_id>/', views.share_document, name='share_document'),
    path('document/manage_access/<int:doc_id>/', views.manage_access, name='manage_access'),
    path("document/view/<int:doc_id>/", views.document_view, name="document_view"),
    path("document/read/<int:doc_id>/", views.read_document, name="read_document"),
    path("document/<int:doc_id>/add_comment/", views.add_comment, name="add_comment"),
    path('ws/document/<int:doc_id>/', consumers.EditorConsumer.as_asgi()),
    path('document/<int:doc_id>/download/', views.download_document, name='download_document'),
    path('document/<int:doc_id>/versions/', views.view_versions, name='view_versions'),
    path('api/document/<int:doc_id>/versions/', views.get_document_versions, name='get_document_versions'),
    path('api/document/<int:doc_id>/restore/<int:version_id>/', views.restore_version, name='restore_version'),
    path('document/<int:doc_id>/version/<int:version_id>/', views.view_version_content, name='view_version_content'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

websocket_urlpatterns = [
    path('ws/document/<int:doc_id>/', consumers.EditorConsumer.as_asgi()),
]
